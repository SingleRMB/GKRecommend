from django.contrib import admin
from .models import CollegeApplication


admin.site.register(CollegeApplication)  # 为CollegeApplication提供后台接口，方便管理

# Register your models here.
