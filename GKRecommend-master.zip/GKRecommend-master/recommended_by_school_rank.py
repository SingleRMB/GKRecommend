import csv
import json
import math
# ecommended_by_profession_rank.py -- 通过全国高校排名推荐高校

# 读取地理位置映射关系
def read_location_mapping():
    with open('./location_mapping.json','r') as jsonfile:
        mapping = json.load(jsonfile)
        # print(mapping)
        return mapping

def get_location_by_province(province,mapping):
    return mapping.get(province, None)

# 读取院校信息
def read_college_info(filename):
    colleges = {}
    with open(filename,'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            college_name = row['院校']
            # 如果主键已经存在,那么直接添加专业进该主键
            if college_name in colleges:
                colleges[college_name].append({
                    '专业': row['专业'],
                    # 将分数,位次转化为整数类型
                    '录取最低分': int(row['最低分']),
                    '对应省排名': int(row['位次']),
                    '科目': row['科目'],
                    '是否为985': int(row['985']),
                    '是否为211': int(row['211']),
                    '地理位置': row['地理位置'],
                })
            else:
                colleges[college_name] = [{
                    '专业': row['专业'],
                    # 将分数,位次转化为整数类型
                    '录取最低分': int(row['最低分']),
                    '对应省排名': int(row['位次']),
                    '科目': row['科目'],
                    '是否为985': int(row['985']),
                    '是否为211': int(row['211']),
                    '地理位置': row['地理位置'],
                }]
    return colleges

def read_user_info():
    # 用户输入考生信息
    user_info = {}
    user_info['姓名'] = input('请输入考生姓名:')
    user_info['分数'] = int(input('请输入考生分数'))
    user_info['位次'] = int(input('请输入根据一分一段表相对应的省内排名:'))
    user_info['第一志愿专业'] = input('请输入考生第一志愿专业')
    user_location = input('请输入考生所在地理位置(省份):')
    location_mapping = read_location_mapping()
    user_info['地理位置'] = get_location_by_province(user_location, location_mapping)
    return user_info

#CRITIC权重算法推荐函数
def recommend_college(college_info,user_info,weights):
    # 归一化权重,确保各项权重都在0-1之间,而且其加和为1
    total_weight = sum(weights.values())
    # k->key:分数、第一志愿专业、地理位置;v->value:各项权重
    normalized_weights = {k: v / total_weight for k, v in weights.items()}
    distance = {}
    # print(college_info.items())
    for college, info_list in college_info.items():
        # print(college)
        # print(info[1]['录取最低分'])
        # print(info_list)
        for info in info_list:
            if info['录取最低分'] - user_info['分数'] >= 10:
                continue
            elif info['对应省排名'] < user_info['位次']:
                continue
            else:
                # print(info)
                # print(int(info['录取最低分']))
                score_distance = (info['录取最低分'] - user_info['分数']) ** 2 * normalized_weights['分数']
                major_distance = int(info['专业'] != user_info['第一志愿专业']) ** 2 * normalized_weights['第一志愿专业']
                location_distance = int(info['地理位置'] != user_info['地理位置']) ** 2 * normalized_weights['地理位置']
                total_distance = math.sqrt(score_distance + major_distance + location_distance)
                distance.setdefault(college, float('inf'))
                if total_distance < distance[college]:
                    distance[college] = total_distance
    sorted_colleges = sorted(distance, key=distance.get)
    return sorted_colleges

#读取全国大学排名信息
def read_unirank_info(filename):
    colleges_rank = {}
    with open(filename,'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            college_name = row['院校']
            colleges_rank[college_name].append({
                '排名': int(row['排名']),
                '总分': float(row['总分'])
            })

def main():

    college_info = read_college_info('score_data/allpredict.csv')
    # print(college_info)

    user_info = read_user_info()
    # 定义权重
    weights = {
        '第一志愿专业': 0.3,
        '地理位置': 0.4,
        '分数': 0.3,
    }
    recommend_colleges = recommend_college(college_info,user_info,weights)
    recommend_colleges = recommend_colleges[:15]
    unirank_data = read_unirank_info('unirank/unirank.csv')
    print('根据您的输入,推荐的院校列表如下:')
    for college in recommend_colleges:
        print(college)


if __name__ == '__main__':
    main()
