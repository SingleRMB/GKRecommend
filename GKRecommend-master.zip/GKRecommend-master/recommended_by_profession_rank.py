import csv
import json
import math
# recommended_by_profession_rank.py -- 通过全国高校对应专业排名推荐学校

# 读取地理位置映射关系
def read_location_mapping():
    with open('./location_mapping.json','r') as jsonfile:
        mapping = json.load(jsonfile)
        # print(mapping)
        return mapping

def get_location_by_province(province,mapping):
    return mapping.get(province, None)

#读取高校录取成绩以及地理位置的信息
def read_college_info(filename):
    colleges = {}
    with open(filename,'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            college_name = row['院校'] #读取院校名称,作为字典的主键
            # 如果主键已经存在,那么直接添加专业进该主键
            if college_name in colleges:
                colleges[college_name].append ({
                    '专业': row['专业'],
                    # 将分数,位次转化为整数类型
                    '录取最低分':int(row['最低分']),
                    '对应省排名':int(row['位次']),
                    '科目':row['科目'],
                    '是否为985':int(row['985']),
                    '是否为211':int(row['211']),
                    '地理位置':row['地理位置'],
                })
            # 如果主键不存在,即要添加该学校名称为主键
            else:
                colleges[college_name] = [{
                    '专业': row['专业'],
                    # 将分数,位次转化为整数类型
                    '录取最低分': int(row['最低分']),
                    '对应省排名': int(row['位次']),
                    '科目': row['科目'],
                    '是否为985': int(row['985']),
                    '是否为211': int(row['211']),
                    '地理位置': row['地理位置'],
                }]
    return colleges
#评分和分数的换算
def map_rating_to_score(rating):
    if rating == 'A+':
        return 100
    elif rating == 'A':
        return 90
    elif rating == 'A-':
        return 80
    elif rating == 'B+':
        return 70
    elif rating == 'B':
        return 60
    elif rating == 'B-':
        return 50
    elif rating == 'C+':
        return 40
    elif rating == 'C':
        return 30
    elif rating == 'C-':
        return 20
    else:
        return 0
def read_subrank_info(filename):
    colleges = {}
    with open(filename,'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            college_name = row['院校']  # 读取院校名称,作为字典的主键
            # 如果主键已经存在,那么直接添加专业进该主键
            if college_name in colleges:
                colleges[college_name].append({
                    '专业': row['专业'],
                    '评级': map_rating_to_score(row['评级'])
                })
            # 如果主键不存在,即要添加该学校名称为主键
            else:
                colleges[college_name] =[{
                    '专业': row['专业'],
                    '评级': map_rating_to_score(row['评级'])
                }]
    return colleges


def read_user_info():
    # 用户输入考生信息
    user_info = {}
    user_info['姓名'] = input('请输入考生姓名:')
    user_info['分数'] = int(input('请输入考生分数'))
    user_info['位次'] = int(input('请输入根据一分一段表相对应的省内排名:'))
    user_info['第一志愿专业'] = input('请输入考生第一志愿专业')
    user_location = input('请输入考生所在地理位置(省份):')
    location_mapping = read_location_mapping()
    user_info['地理位置'] = get_location_by_province(user_location, location_mapping)
    return user_info

def recommend_college(college_info,user_info,weights):
    # 归一化权重,确保各项权重都在0-1之间,而且其加和为1
    total_weight = sum(weights.values())
    #k->key:分数、第一志愿专业、地理位置;v->value:各项权重
    normalized_weights = {k: v / total_weight for k,v in weights.items()}
    # 计算每个考生与每个院校之间的距离,创建一个空字典用于接收临时最小距离
    distance = {}
    #print(college_info)
    for college,info_list in college_info.items():
        # print(college)
        # print(info[1]['录取最低分'])
        # print(info_list)
        for info in info_list:
            if info['录取最低分']-user_info['分数']>=10:
                continue
            elif info['对应省排名'] < user_info['位次']:
                continue
            else:
                # print(info)
                #print(int(info['录取最低分']))
                score_distance = (info['录取最低分']-user_info['分数'])**2 * normalized_weights['分数']
                major_distance = int(info['专业'] != user_info['第一志愿专业'])**2 * normalized_weights['第一志愿专业']
                location_distance = int(info['地理位置'] != user_info['地理位置'])**2 * normalized_weights['地理位置']
                total_distance = math.sqrt(score_distance + major_distance + location_distance)
                distance.setdefault(college , float('inf'))
                if total_distance < distance[college]:
                    distance[college] = total_distance
    sorted_colleges = sorted(distance, key=distance.get)
    return sorted_colleges

def main():

    college_info = read_college_info('score_data/allpredict.csv')
    # print(college_info)

    user_info = read_user_info()
    # 定义权重
    weights = {
        '第一志愿专业': 0.3,
        '地理位置': 0.4,
        '分数': 0.3,
    }
    recommend_colleges = recommend_college(college_info,user_info,weights)
    # print(recommend_colleges)
    recommend_colleges = recommend_colleges[:15]
    subrank_data = read_subrank_info('unirank/subrank.csv')
    # print(subrank_data)
    print('根据您的输入,推荐的院校列表如下:')
    for college in recommend_colleges:
        print(college)
if __name__ == '__main__':
    main()
