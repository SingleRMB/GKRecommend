import json

def get_location(province):
    with open('location_mapping.json', 'r') as file:
        location_mapping = json.load(file)
    return location_mapping.get(province, '')

user_province = input('请输入考生所在省份: ')
location = get_location(user_province)
print('考生所在地理位置:', location)