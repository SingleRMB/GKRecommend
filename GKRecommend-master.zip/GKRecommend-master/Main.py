import recommended_by_location
import recommended_by_school_rank
import recommended_by_profession_rank
import json
import csv

#读取高校录取成绩以及地理位置的信息
def read_college_info(filename):
    colleges = {}
    with open(filename,'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            college_name = row['院校'] #读取院校名称,作为字典的主键
            # 如果主键已经存在,那么直接添加专业进该主键
            if college_name in colleges:
                colleges[college_name].append ({
                    '专业': row['专业'],
                    # 将分数,位次转化为整数类型
                    '录取最低分':int(row['最低分']),
                    '对应省排名':int(row['位次']),
                    '科目':row['科目'],
                    '是否为985':int(row['985']),
                    '是否为211':int(row['211']),
                    '地理位置':row['地理位置'],
                })
            # 如果主键不存在,即要添加该学校名称为主键
            else:
                colleges[college_name] = [{
                    '专业': row['专业'],
                    # 将分数,位次转化为整数类型
                    '录取最低分': int(row['最低分']),
                    '对应省排名': int(row['位次']),
                    '科目': row['科目'],
                    '是否为985': int(row['985']),
                    '是否为211': int(row['211']),
                    '地理位置': row['地理位置'],
                }]
    return colleges



# 读取用户信息
def read_user_info():
    user_info = {}
    user_info['姓名'] = input('请输入考生姓名:')
    user_info['分数'] = int(input('请输入考生分数'))
    user_info['位次'] = int(input('请输入根据一分一段表相对应的省内排名:'))
    user_info['第一志愿专业'] = input('请输入考生第一志愿专业')
    user_location = input('请输入考生所在地理位置(省份):')
    # 根据用户选择的地理位置，获取对应的地理位置值，比如北上广、华东地区等
    user_info['地理位置'] = get_location_mapping(user_location)
    return user_info

# 读取与省级区域与地理位置的映射关系 -- location_mapping.json映射文件
def get_location_mapping(user_location):
    # 读取地理位置映射关系
    with open('location_mapping.json', 'r') as f:
        location_mapping = json.load(f)
    # 根据用户输入的省份，获取对应的地理位置值
    return location_mapping.get(user_location, "")

def main():
    # 用户选择推荐方法
    print("请选择推荐方法:")
    print("1. 通过地理位置推荐高校")
    print("2. 通过全国高校排名推荐高校")
    print("3. 通过全国高校对应专业排名推荐学校")
    choice = int(input("请输入选择的方法序号:"))
    college_info = read_college_info('score_data/allpredict.csv')
    if choice == 1: # 通过地理位置推荐高校
        # 用户输入信息
        user_info = read_user_info()
        # 定义权重
        weights = {
            '第一志愿专业': 0.1,
            '地理位置': 0.6,
            '分数': 0.3,
        }
        recommend_colleges = recommended_by_location.recommend_college(college_info,user_info,weights)
    elif choice == 2:
        # 通过全国高校排名推荐高校
        user_info = read_user_info()
        weights = {
            '第一志愿专业': 0.3,
            '地理位置': 0.4,
            '分数': 0.3,
        }
        recommend_colleges = recommended_by_school_rank.recommend_college(college_info,user_info,weights)
    elif choice == 3:
        # 通过全国高校对应专业排名推荐学校
        user_info = read_user_info()
        weights = {
            '第一志愿专业': 0.3,
            '地理位置': 0.4,
            '分数': 0.3,
        }
        recommend_colleges = recommended_by_profession_rank.recommend_college(college_info,user_info,weights)
    else:
        print("无效的选择")
    recommend_colleges = recommend_colleges[:15]
    print('根据您的输入,推荐的院校列表如下:')
    for college in recommend_colleges:
        print(college)

if __name__ == '__main__':
    main()
